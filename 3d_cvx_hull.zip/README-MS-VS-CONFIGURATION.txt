System Requirements
1. Windows Operating System 
2. MS Visual Studio 2015
 
The following is configuration in MS Visual Studio 2015 to build this project.
1. Solution Configuration - Debug
2. Solution Platform - x86

If using other versions of MS Visual Studio, change the "platform toolset" 
in Project->Properties to "v140". 

The standalone executable for the demo is available in the folder named 
"StandaloneExecutable-ForDemo"